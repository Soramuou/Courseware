﻿using System;

namespace UnitTestLesson01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("单元测试的目标系统 ，假定尚未完成……");
        }
    }
}
