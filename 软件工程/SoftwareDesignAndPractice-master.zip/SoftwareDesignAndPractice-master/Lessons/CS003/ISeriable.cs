﻿namespace CS003
{
    interface ISeriable
    {
        void Read();
        void Write();
    }
}
