
class Info:
    def __init__(self):
        self.node_id = 0
        self.dit_func = {}

class Node:
    def __init__(self, info):
        self.father = []
        self.child = []
        self.define = []
        self.user = []
        self.id = info.node_id
        info.node_id += 1
        self.Vis = 0
        self.branch = 0
        self.lable = ""
        self.labl = ""


def merge_cfg(cfg):
    if cfg.Vis == 1 or len(cfg.child) == 0:
        cfg.Vis = 1
        return True
    # cfg.Vis = 3
    if len(cfg.child) == 1 and len(cfg.father) <= 1:
        node = cfg.child[0]
        if len(node.child) <=1 and len(node.father) ==1:
            cfg.child.remove(node)
            # node.father.remove(cfg)
            if len(node.child) == 1:
                cfg.child.append(node.child[0])
            if cfg.labl == "":
                cfg.labl = node.labl
            cfg.define += node.define
            cfg.user += node.user
            merge_cfg(cfg)
            return True
    if len(cfg.child) == 1 and len(cfg.father) == 1 and len(cfg.define) == 0 and len(cfg.user) == 0 and cfg.id != 0:
        node = cfg.child[0]
        if node.id > cfg.id :
            node.father.remove(cfg)
            nf = cfg.father[0]
            nf.child.remove(cfg)
            nf.child.append(node)
            node.father.append(nf)
            if cfg.labl != "":
                node.labl = cfg.labl

            return False

    cfg.Vis = 1
    for child in cfg.child:
        flag = merge_cfg(child)
        if flag == False:
            cfg.Vis = 0
            merge_cfg(cfg)
            break
    return True




def get_att_name(ast):
    vlist = [getattr(ast, n) for n in ast.attr_names]
    name = vlist[0]
    return name

def getArrayRef(ast, node):
    c1 = ast.children()[0][1]
    sname = get_att_name(c1)
    c2 = ast.children()[1][1]
    if c2.__class__.__name__ == "ID":
        name = get_att_name(c2)
        # sname = sname + "[" + name +"]"
        node.user.append(name)
    if c2.__class__.__name__ == "Constant":
        vlist = [getattr(c2, n) for n in c2.attr_names]
        k = vlist[1]
        # sname = sname + "[" + str(k) + "]"
    return sname

def assignment(node, ast, isDefine):
    for (child_name, child) in ast.children():
        if child.__class__.__name__ == "ID":
            name = get_att_name(child)
            if isDefine == True:
                node.define.append(name)
                isDefine = False
            else:
                node.user.append(name)
        if child.__class__.__name__ == "BinaryOp" or child.__class__.__name__ == "BinaryOp":
            assignment(node, child, isDefine)
        if child.__class__.__name__ == "ArrayRef":
            name = getArrayRef(child,node)
            if isDefine == True:
                node.define.append(name)
                isDefine = False
            else:
                node.user.append(name)


def if_ast(ast, info):
    root = Node(info)
    tail = Node(info)
    k = 0
    root.lable = "IF"
    for (child_name, child) in ast.children():
        k += 1
        if child.__class__.__name__ == "BinaryOp":
            assignment(root, child, False)
        if child.__class__.__name__ == "Compound":
            root_node, tail_node = dfs_ast(child, info)
            if k == 2:
                root_node.labl = "True"
            else:
                root_node.labl = "False"
            root.child.append(root_node)
            root_node.father.append(root)
            tail_node.child.append(tail)
            tail.father.append(tail_node)
        if child.__class__.__name__ == "If":
            root_node, tail_node = if_ast(child, info)
            root_node.labl = "False"
            root.child.append(root_node)
            root_node.father.append(root)
            tail_node.child.append(tail)
            tail.father.append(tail_node)
    if k < 3:
        root.child.append(tail)
        tail.father.append(root)
        tail.labl = "False"
    return root, tail

def while_ast(ast, info):
    root = Node(info)
    root.lable = "WHILE"
    tail = Node(info)
    for (child_name, child) in ast.children():
        if child.__class__.__name__ == "Compound":
            root_node, tail_node = dfs_ast(child, info)
            root_node.labl = "True"
            root.child.append(root_node)
            root_node.father.append(root)
            tail_node.child.append(root)
            root.father.append(tail_node)
        if child.__class__.__name__ == "BinaryOp":
            assignment(root, child, False)
    root.child.append(tail)
    tail.labl = "False"
    tail.father.append(root)
    return root, tail

# def DoWhile_ast(ast, info):
#     root = Node(info)
#     tail = Node(info)
#     root.lable = "DO-WHILE"
#     for (child_name, child) in ast.children():
#         if child.__class__.__name__ == "Compound":
#             root_node, tail_node = dfs_ast(child, info)
#             root.child.append(root_node)
#             root_node.father.append(root)
#             tail_node.child.append(tail)
#             tail.father.append(tail_node)
#         if child.__class__.__name__ == "BinaryOp":
#             assignment(tail, child, False)
#     tail.child.append(root)
#     root.father.append(child)
#     return root, tail


def decl_ast(ast, info):
    flag = False
    node = Node(info)
    for (child_name1, child1) in ast.children():
        if child1.__class__.__name__ == "Constant":
            flag = True
        if child1.__class__.__name__ == "ID":
            flag = True
            name = get_att_name(child1)
            node.user.append(name)
    if flag:
        name = get_att_name(ast)
        node.define.append(name)
    return node

# def for_ast(ast, info):
#     root = Node(info)
#     tail = root
#     flag = False
#     root.lable = "FOR"
#     for (child_name, child) in ast.children():
#         if child.__class__.__name__ == "DeclList" or child.__class__.__name__ == "ExprList":
#             root_node, tail_node = dfs_ast(child, info)
#             tail.child.append(root_node)
#             root_node.father.append(tail)
#             tail = tail_node
#         if child.__class__.__name__ == "BinaryOp":
#             node = Node(info)
#             assignment(node, child, False)
#             tail.child.append(node)
#             node.father.append(tail)
#             tail = node
#         if child.__class__.__name__ == "Assignment" or child.__class__.__name__ == "UnaryOp":
#             flag = True
#             t_node = Node(info)
#             if child.__class__.__name__ == "UnaryOp":
#                 name = get_att_name(child)
#                 t_node.define.append(name)
#                 t_node.user.append(name)
#             if child.__class__.__name__ == "Assignment":
#                 assignment(t_node,child,False)
#         if child.__class__.__name__ == "Compound":
#             root_node, tail_node = dfs_ast(child, info)
#             tail.child.append(root_node)
#             root_node.father.append(tail)
#             tail = tail_node
#     if flag == True:
#         tail.child.append(t_node)
#         t_node.father.append(tail)
#         tail = t_node
#     tail.child.append(root)
#     root.father.append(tail)
#     tail = Node(info)
#     root.child.append(tail)
#     tail.father.append(root)
#     return root,tail

def dfs_define(node, ast):
    for (child_name, child) in ast.children():
        if child.__class__.__name__ == "ID":
            name = get_att_name(child)
            node.define.append(name)
        else:
            if child.__class__.__name__ == "ArrayRef":
                name = getArrayRef(child, node)
                node.define.append(name)
            else:
                dfs_define(node, child)

def dfs_user(node, ast):
    for (child_name, child) in ast.children():
        if child.__class__.__name__ == "ID":
            name = get_att_name(child)
            node.user.append(name)
        else:
            if child.__class__.__name__ == "ArrayRef":
                name = getArrayRef(child, node)
                node.user.append(name)
            else:
                dfs_user(node, child)


# def switch_ast(ast, info):
#     root = Node(info)
#     tail = Node(info)
#     root.lable = "SWITCH"
#     for (child_name, child) in ast.children():
#         if child.__class__.__name__ == "ID":
#             name = get_att_name(child)
#             root.user.append(name)
#         if child.__class__.__name__ == "Compound":
#             for (child_name1, child1) in child.children():
#                 root_node, tail_root = dfs_ast(child1, info)
#                 root.child.append(root_node)
#                 root_node.father.append(root)
#                 tail_root.child.append(tail)
#                 tail.father.append(tail_root)
#     return root, tail


def dfs_ast(ast, info):

    root = Node(info)
    tail = root
    for (child_name, child) in ast.children():
        if child.__class__.__name__ == "ID":
            name = get_att_name(child)
            root.user.append(name)
        if child.__class__.__name__ == "Decl":
            node = decl_ast(child, info)
            tail.child.append(node)
            node.father.append(tail)
            tail = node
        if child.__class__.__name__ == "FuncDef":
            for (child_name1, child1) in child.children():
                if child1.__class__.__name__ == "Compound":
                    root_node, tail_node = dfs_ast(child1, info)
                    tail.child.append(root_node)
                    root_node.father.append(tail)
                    tail = tail_node
        if child.__class__.__name__ == "Assignment":
            node = Node(info)
            tail.child.append(node)
            node.father.append(tail)
            tail = node
            assignment(node, child, True)
        if child.__class__.__name__ == "If":
            root_node,tail_node = if_ast(child, info)
            tail.child.append(root_node)
            root_node.father.append(tail)
            tail = tail_node
        if child.__class__.__name__ == "While":
            root_node, tail_node = while_ast(child, info)
            tail.child.append(root_node)
            root_node.father.append(tail)
            tail = tail_node
        # if child.__class__.__name__ == "DoWhile":
        #     root_node, tail_node = DoWhile_ast(child, info)
        #     tail.child.append(root_node)
        #     root_node.father.append(tail)
        #     tail = tail_node
        # if child.__class__.__name__ == "For":
        #     root_node, tail_node = for_ast(child, info)
        #     tail.child.append(root_node)
        #     root_node.father.append(tail)
        #     tail = tail_node
        # if child.__class__.__name__ == "Switch":
        #     root_node, tail_node = switch_ast(child, info)
        #     tail.child.append(root_node)
        #     root_node.father.append(tail)
        #     tail = tail_node
        if child.__class__.__name__ == "FuncCall":
            func_id = ""
            node = Node(info)
            tail.child.append(node)
            node.father.append(tail)
            tail = node
            for (child_name1, child1) in child.children():
                if child1.__class__.__name__ == "ID":
                    func_id = get_att_name(child1)
                if child1.__class__.__name__ == "ExprList":
                    if func_id == "ReadLong" or func_id == "scanf":
                        dfs_define(node,child1)
                    else :
                        dfs_user(node, child1)
    return root, tail


def re_id(ast, info):
    if ast.Vis == 0:
        return
    info.node_id += 1
    ast.id = info.node_id
    ast.Vis = 0
    for child in ast.child:
        re_id(child, info)

def rename(ast):
    info = Info()
    re_id(ast, info)

def cfg(ast):
    info = Info()
    ast_root = Node(info)
    root, tail = dfs_ast(ast, info)
    merge_cfg(root)
    rename(root)
    root.father.append(ast_root)
    ast_root.child.append(root)
    return ast_root
