from __future__ import print_function
from pycparser import c_parser

def format_file(filename):
    flag,quote = 0,0
    file = ""
    with open(filename, 'r') as f:
        for line in f.readlines():
            if '#' in line:
                continue
            new_line = ""
            length = len(line)
            for index in range(length):
                if flag == 0 and quote == 0 and line[index] == "\"":
                    quote = 1
                    new_line += line[index]
                    continue
                if flag == 0 and quote == 1 and line[index] == "\"":
                    quote = 0
                    new_line += line[index]
                    continue
                if quote != 1 and flag == 2 and line[index] == "\n":
                    flag = 0
                if quote != 1 and flag == 0 and line[index] == "/" and line[index + 1] == "*":
                    flag = 1
                if quote != 1 and index > 0 and flag == 1 and line[index - 1] == "/" and line[index - 2] == "*":
                    flag = 0
                if quote != 1 and flag == 0 and line[index] == "/" and line[index + 1] == "/":
                    flag = 2
                if flag == 1 or flag == 2:
                    continue
                new_line += line[index]
            file += new_line
    f.close()
    return file

def get_ast(filename):
    file = format_file(filename)
    parser = c_parser.CParser()
    ast = parser.parse(file)
    return ast
