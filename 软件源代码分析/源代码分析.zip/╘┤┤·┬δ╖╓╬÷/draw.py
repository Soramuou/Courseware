# coding=UTF-8
from graphviz import Digraph
from reportlab.pdfgen.canvas import Canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
import webbrowser

def del_re(node, conut):
    node.define = list(set(node.define))
    node.user = list(set(node.user))
    conut.set = set(node.define) | conut.set
    conut.set = set(node.user) | conut.set
    # node.child = list(set(node.child))

class Count:
    def __init__(self):
        self.count = 0;
        self.set = set()


    def selfAdd(self):
        self.count += 1
        return self.count


def dfs_draw(g, cfg, count):
    for child in cfg.child:
        if child.Vis == 2:
            labe = child.labl
            g.edge(str(cfg.id), str(child.id), color='green', label = labe)
        else:
            del_re(child, count)
            label = "D: " + str(child.define) +"\n U: " + str(child.user) + "\n" + str(child.id) +'\n'+ child.lable
            labe = ""
            if len(cfg.child) >= 2:
                labe = child.labl
            g.node(name=str(child.id), color='black',label=label)
            g.edge(str(cfg.id), str(child.id), color='green',label=labe)
            child.Vis = 2
            dfs_draw(g, child, count)


def draw_cfg(cfg,filename):
    g = Digraph(filename)
    g.format = 'jpg'
    cfg.Vis = 2
    count = Count()
    del_re(cfg, count)
    g.node(name=str(cfg.id), color='black', label="START")
    dfs_draw(g, cfg, count)
    g.view()
    return count.set


def get_dg(dg, key, li, cfg, isfirst):
    no = "*" + str(cfg.id) + "*"
    if key in cfg.user:
        if isfirst == True:
            li.append(dg + "-->" + no)
        else:
            if no in dg:
                return
            li.append(dg + "-->" + no)
    if key in cfg.define and isfirst == False:
        return
    if isfirst == False:
        dg = dg + "-->" + no
    isfirst = False
    cfg.Vis += 1
    for child in cfg.child:
        if child.Vis >= child.branch:
            continue
        get_dg(dg, key, li, child, isfirst)
    cfg.Vis -= 1

def dell(li):
    lt = []
    for i in li:
        if i not in lt:
            lt.append(i)
    return lt

def dfs_first(key, li, cfg):
    if cfg.Vis == 1:
        return
    cfg.Vis = 1
    if key in cfg.define:
        li.append(cfg)
    for child in cfg.child:
        dfs_first(key,li,child)

def revist(cfg):
    if cfg.Vis == 0:
        return
    cfg.Vis = 0
    for child in cfg.child:
        revist(child)


def jibranch(cfg):
    if cfg.Vis == 1:
        return
    cfg.Vis = 1
    cfg.branch = 0
    for child in cfg.child:
        if child.Vis == 1:
            continue
        jibranch(child)
        cfg.branch += child.branch
    if cfg.branch == 0:
        cfg.branch = 1


def draw_dg(set1, cfg,filename):
    createVar = globals()
    for st in set1:
        createVar[st] = list()
        first_dot = []
        dfs_first(st, first_dot, cfg)
        revist(cfg)
        for node in first_dot:
            jibranch(node)
            revist(node)
            get_dg("*" + str(node.id) + "*", st, createVar[st], node, True)
    c = Canvas(filename + '.pdf')
    # c.setFont('STSong-Light', 12)
    cut = 0
    for st in set1:
        dg_pfd = st
        c.drawString(50, 800 - cut, dg_pfd)
        cut += 18
        if 800 - cut < 0:
            c.showPage()
            cut = 0
        createVar[st] = dell(createVar[st])
        for sr in createVar[st]:
            dg_pfd = sr.replace('*', '')
            c.drawString(50, 800- cut, dg_pfd)
            cut += 12
            if 800 - cut < 50:
                c.showPage()
                cut = 0
    c.save()
    webbrowser.open(filename + '.pdf')