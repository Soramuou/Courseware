import get_ast as ast
import ast2cfg as cfg
import draw as draw
import sys
sys.path.extend(['.', '..'])

# def diedai(f,ast):
#     for (child_name, child) in ast.children():
#         f.write(child_name + '/n')
#         if child.__class__.__name__ == "FuncDef":
#             diedai(f,child)
#         else:
#             f.write(child + '/n')

if __name__ == "__main__":
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        filename = "collatz.c"



    ast = ast.get_ast(filename)
    print('ast.ext', ast.ext[0])
    with open('ast.txt', 'w') as f:
        for row in ast:
            f.write(str(row))
    CFG = cfg.cfg(ast)

    # str_set = draw.draw_cfg(CFG,filename)
    # cfg.rename(CFG.child[0])
    # draw.draw_dg(str_set, CFG,filename)


